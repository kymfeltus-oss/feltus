import jwt from "jsonwebtoken";
import { FeltusBaseClient } from "./lib/feltus-client.js";
import { FeltusAIController } from "./lib/feltus-ai.js";
import dotenv from "dotenv";
dotenv.config();

const API_URL = "http://127.0.0";
const SUPABASE_SERVICE_KEY = "sb_secret_N7UND0UgjKTVK-Uodkm0Hg_xSvEMPvz";

async function executeAIPipeline() {
  console.log("\n=== FELTUS LABS: COGNITIVE DATA INGESTION ENGINE ===");
  const db = new FeltusBaseClient(API_URL, SUPABASE_SERVICE_KEY);
  const ai = new FeltusAIController("http://127.0.0.1:11434");
  try {
    console.log("Reading real-time assets from database...");
    const records = await db.from("user_assets").select("*", {});
    if (!records || records.length === 0) {
      console.log("⚠ No active database rows found to ingest.");
      return;
    }
    console.log("Ingesting data history records into local AI model inference...");
    const targetRecord = records[records.length - 1];
    const contextPrompt = "Analyze asset track sequence securely: " + targetRecord.id;
    console.log("Sending token array context straight to private Ollama container loop...");
    const aiResponse = await ai.chatCompletion("llama3:8b", [
      { role: "system", content: "You are the core cloud engineering agent of Feltus Labs." },
      { role: "user", content: contextPrompt }
    ]);
    console.log("\n============= LOCAL AI MODEL SYSTEM RESPONSE =============");
    console.log(aiResponse.content);
    console.log("===========================================================");
  } catch (error) {
    console.error("❌ Ingestion Block Failure:", error.message);
  }
}
executeAIPipeline();