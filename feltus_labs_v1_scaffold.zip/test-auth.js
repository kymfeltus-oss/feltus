import jwt from 'jsonwebtoken';
import { FeltusBaseClient } from './lib/feltus-client.js';
import dotenv from 'dotenv';

dotenv.config();

const JWT_SECRET = process.env.FELTUS_JWT_SECRET || "super-secret-jwt-token-with-at-least-32-characters-long";
const USER_ID = process.env.TEST_USER_UUID || "d3b07384-d113-4956-a56e-ecd16d475ab5";
const API_URL = process.env.FELTUS_API_URL || "http://127.0.0";

console.log('\n--- FELTUS LABS: DATA SECURITY HANDSHAKE VERIFICATION ---');

const payload = {
  aud: "authenticated",
  role: "authenticated",
  sub: USER_ID,
  email: "developer@feltuslabs.local",
  app_metadata: { provider: "email" },
  user_metadata: {},
  exp: Math.floor(Date.now() / 1000) + (60 * 60)
};

const token = jwt.sign(payload, JWT_SECRET);
console.log('✔ Cryptographic Auth Token Generated.');

const feltus = new FeltusBaseClient(API_URL, token);

async function testDatabasePrivacy() {
  try {
    console.log('Connecting to FeltusBase REST API Gateway...');
    console.log('Attempting secure entry insertion...');
    
    const insertResult = await feltus.from('user_assets').insert([
      {
        user_id: USER_ID,
        asset_name: "Feltus Cloud Compute Engine Core v1",
        payload: { cluster_nodes: 4, isolation_level: "maximum" }
      }
    ]);
    console.log('✔ Write Validation Successful! Asset Synchronized.');

    console.log('Querying isolated database records back...');
    const fetchResult = await feltus.from('user_assets').select('*', { user_id: USER_ID });
    
    console.log(`✔ Read Validation Successful! Retrieved ${fetchResult.length} Row(s).`);
    console.log('Data Record Sample:', JSON.stringify(fetchResult[0], null, 2));

  } catch (error) {
    console.error('❌ Data Validation Failure:', error.message);
  }
}

testDatabasePrivacy();