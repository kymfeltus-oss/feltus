export interface Database {
  public: {
    Tables: {
      feltus_applications: {
        Row: {
          id: string
          owner_id: string
          app_name: string
          environment: string
          created_at: string
        }
        Insert: {
          id?: string
          owner_id: string
          app_name: string
          environment?: string
          created_at?: string
        }
      }
      user_assets: {
        Row: {
          id: string
          app_id: string | null
          user_id: string
          asset_name: string
          payload: Json
          created_at: string
        }
      }
    }
  }
}
