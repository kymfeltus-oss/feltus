import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// FIXED: Pointing cleanly to the base API Gateway context path expected by Kong
const SUPABASE_REST_URL = "http://127.0.0";
const SUPABASE_SERVICE_KEY = "sb_secret_N7UND0UgjKTVK-Uodkm0Hg_xSvEMPvz";
const TEST_USER_UUID = "d3b07384-d113-4956-a56e-ecd16d475ab5";

const server = http.createServer(async (req, res) => {
    if (req.method === 'OPTIONS') {
        res.writeHead(204, {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type'
        });
        return res.end();
    }

    if (req.url.startsWith('/api/assets') && req.method === 'GET') {
        try {
            console.log('[Proxy Request]: Intercepted GET /api/assets. Calling database gateway...');
            const response = await fetch(`${SUPABASE_REST_URL}?select=*`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'apikey': SUPABASE_SERVICE_KEY,
                    'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`
                }
            });
            if (!response.ok) throw new Error(`Gateway Error ${response.status}: ${await response.text()}`);
            const data = await response.json();
            res.writeHead(200, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
            return res.end(JSON.stringify(data));
        } catch (err) {
            console.error('❌ UPSTREAM ENGINE BRIDGE FAILURE (GET):', err.message);
            res.writeHead(502, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
            return res.end(JSON.stringify({ error: "Upstream gateway unavailable", details: err.message }));
        }
    }

    if (req.url.startsWith('/api/assets') && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => { body += chunk.toString(); });
        req.on('end', async () => {
            try {
                const parsedBody = JSON.parse(body);
                console.log(`[Proxy Request]: Intercepted POST /api/assets for Resource: "${parsedBody.asset_name}"`);
                const response = await fetch(SUPABASE_REST_URL, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'apikey': SUPABASE_SERVICE_KEY,
                        'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
                        'Prefer': 'return=representation'
                    },
                    body: JSON.stringify([{
                        user_id: TEST_USER_UUID,
                        asset_name: parsedBody.asset_name || "Unnamed Core Asset Element",
                        payload: { client_origin: "Feltus Engine Control Proxy", status: "verified_operational" }
                    }])
                });
                if (!response.ok) throw new Error(`Gateway Write Rejected ${response.status}: ${await response.text()}`);
                const data = await response.json();
                res.writeHead(200, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
                return res.end(JSON.stringify(data));
            } catch (err) {
                console.error('❌ UPSTREAM ENGINE BRIDGE FAILURE (POST):', err.message);
                res.writeHead(502, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
                return res.end(JSON.stringify({ error: "Upstream database sync write failure", details: err.message }));
            }
        });
        return;
    }

    if (req.url === '/' || req.url === '/index.html') {
        const filePath = path.join(__dirname, '../index.html');
        fs.readFile(filePath, (err, content) => {
            if (err) {
                res.writeHead(500);
                return res.end('Error loading dashboard view index.html resource');
            }
            res.writeHead(200, { 'Content-Type': 'text/html' });
            return res.end(content);
        });
        return;
    }
    res.writeHead(404);
    res.end('Not Found');
});

server.listen(8080, '127.0.0.1', () => {
    console.log('\n=== FELTUS LABS: INTEGRATED PRIVATE PROXY SERVER LIVE ===');
    console.log('Console Address: http://127.0.0.1:8080');
    console.log('Monitoring internal data packets across network loops...\n');
});